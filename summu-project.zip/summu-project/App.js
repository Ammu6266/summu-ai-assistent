
import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  StatusBar,
} from 'react-native';

export default function App() {
  const [active, setActive] = useState(false);

  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" />

      <Text style={styles.logo}>SUMMU</Text>
      <Text style={styles.sub}>YOUR PERSONAL AI ASSISTANT</Text>

      <View style={styles.circle}>
        <Text style={styles.ai}>S</Text>
      </View>

      <Text style={styles.title}>Hello, I am SUMMU</Text>
      <Text style={styles.message}>
        आपकी AI असिस्टेंट, हमेशा आपकी मदद के लिए।
      </Text>

      <TouchableOpacity
        style={styles.mic}
        onPress={() => setActive(!active)}
      >
        <Text style={styles.micText}>🎙️</Text>
      </TouchableOpacity>

      <Text style={styles.status}>
        {active ? 'बटन दबाया गया' : 'Hey SUMMU कहकर बुलाएँ'}
      </Text>

      <Text style={styles.footer}>POWERED BY AI</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#050B18',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
  },
  logo: {
    color: '#42D9FF',
    fontSize: 38,
    fontWeight: 'bold',
    letterSpacing: 7,
  },
  sub: {
    color: '#8296B5',
    fontSize: 10,
    letterSpacing: 3,
    marginTop: 8,
  },
  circle: {
    width: 180,
    height: 180,
    borderRadius: 90,
    borderWidth: 3,
    borderColor: '#42D9FF',
    alignItems: 'center',
    justifyContent: 'center',
    marginVertical: 55,
    backgroundColor: '#10243B',
  },
  ai: {
    color: '#42D9FF',
    fontSize: 85,
    fontWeight: 'bold',
  },
  title: {
    color: 'white',
    fontSize: 25,
    fontWeight: 'bold',
  },
  message: {
    color: '#9EADC4',
    fontSize: 14,
    marginTop: 12,
    textAlign: 'center',
  },
  mic: {
    width: 75,
    height: 75,
    borderRadius: 40,
    backgroundColor: '#087FA8',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 40,
  },
  micText: {
    fontSize: 32,
  },
  status: {
    color: '#42D9FF',
    marginTop: 18,
  },
  footer: {
    color: '#526780',
    position: 'absolute',
    bottom: 30,
    letterSpacing: 4,
    fontSize: 10,
  },
});
